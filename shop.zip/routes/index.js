var   express = require('express');

var router = express.Router();

const path = require("path");

// 引用dbutil文件访问数据库

const   dbutil=require("../dbutil/dbutil");

 

// 设置访问项目首页（登录页面）的路由路径

router.get('shop/login-register.html', function (req, res,   next) {

      res.sendFile(global.webPath  +   'login.html');

});

 

module.exports = router;