var mysql      = require('mysql');
var connection = mysql.createConnection({
  host     : 'localhost',
  user     : 'root',
  password : '123456',
  database : 'sale'
});
 function connect() {
    connection.connect();
 }
 function addlistlog(musicname,ip,type) {
    var  addSql = 'INSERT INTO listen_log(musicname,ip,createtime) VALUES(?,?,?)';
    var  addSqlParams = [musicname, ip,new Date().getTime()];
    if(type==2){
        addSql = 'INSERT INTO  download_log(musicname,ip,createtime) VALUES(?,?,?)';
    }
    //增
    connection.query(addSql,addSqlParams,function (err, result) {
            if(err){
             console.log('[INSERT ERROR] - ',err.message);
             return;
            }        
     
           console.log('--------------------------INSERT----------------------------');
           //console.log('INSERT ID:',result.insertId);        
           console.log('INSERT ID:',result);        
           console.log('-----------------------------------------------------------------\n\n');  
    });
    connection.query('SELECT 1 + 1 AS solution', function (error, results, fields) {
      if (error) throw error;
      console.log('The solution is: ', results[0].solution);
    });
   // connection.destroy();
 }
 function  addUser(username,password,email) {
  var  addSql = 'INSERT INTO user(username,password,email) VALUES(?,?,?)';
  var  addSqlParams = [username, password,email];  var  querySqlParams = [username, password];
  var  queryql = 'SELECT 1 from user  where username=?';
  connection.query(queryql,querySqlParams, function (error, results, fields) {
    if (error) throw error;
    console.log('The solution is: ', results[0]['1']);
    if (results[0]['1']==1){
        return '用户名或者邮箱被占用';
    }


  });
  //增
  connection.query(addSql,addSqlParams,function (err, result) {
          if(err){
           console.log('[INSERT ERROR] - ',err.message);
           return;
          }        
          return 'ok';
         console.log('--------------------------INSERT----------------------------');
         //console.log('INSERT ID:',result.insertId);        
         console.log('INSERT ID:',result);        
         console.log('-----------------------------------------------------------------\n\n');  
  });
  connection.query('SELECT 1 + 1 AS solution', function (error, results, fields) {
    if (error) throw error;
    console.log('The solution is: ', results[0].solution);
  });
 // connection.destroy();
}
 module.exports = {addUser,
    addlistlog,connect,connection
   }
