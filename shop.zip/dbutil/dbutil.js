let   mysql=require("mysql");

let conn=mysql.createConnection({

      user : '1',

      u_name : 'admin',

      u_password: 'admin',

      u_role: '0',

      database: '宜家'

})

conn.connect();

module.exports=conn;