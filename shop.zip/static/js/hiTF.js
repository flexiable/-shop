$(".container").removeAttr("style");
	$(".containner-body").removeAttr("style");