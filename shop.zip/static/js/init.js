$(function () {
	$(".signin-2").remove();
	$(".zwsoft-login .zwsoft-login-box .left").remove();
	$(".zwsoft-login .zwsoft-login-box .top").remove();
	$(".zwsoft-register .zwsoft-register-box .left, .zwsoft-resetpassword .zwsoft-resetpassword-box .left").remove();
	$(".zwsoft-register .zwsoft-register-box .top, .zwsoft-resetpassword .zwsoft-resetpassword-box .top").remove();
	$(".zwsoft-register .form-outset-2").remove();
	$(".zwsoft-resetpassword .row .col-sm-12 .mobile-une").remove();
	$(".text-danger-1").remove();
})