var createError =   require('http-errors');

var express = require('express');
var multer  = require('multer')
var path = require('path');

var cookieParser =   require('cookie-parser');
const http = require("http");
const fs = require("fs");
var logger = require('morgan');

var db=require('./db');
const bodyParser = require('body-parser')
// 注册body-parser 中间键 解析提交的内容
var createFolder = function(folder){
    try{
        fs.accessSync(folder); 
    }catch(e){
        fs.mkdirSync(folder);
    }  
};

var uploadFolder = './upload/';

createFolder(uploadFolder);
// 通过 filename 属性定制
var storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, uploadFolder);    // 保存的路径，备注：需要自己创建
    },
    filename: function (req, file, cb) {
        // 将保存文件名设置为 字段名 + 时间戳，比如 logo-1478521468943
        cb(null, file.fieldname + '-' + Date.now()+".jpg");  
    }
});

// 通过 storage 选项来对 上传行为 进行定制化
var upload = multer({ storage: storage })

// const server = http.createServer(function(req,res){
//     //设置响应头
//     res.writeHead(200,{"Content-Type":"text/html;charset=UTF-8"})
// 	//设置访问的url路径
//     if(req.url == "/" || req.url == "/index"){
// 	//路径为相对路径，也就是说与这个js文件同级的有一个html文件
//         fs.readFile("login-register.html",function(err,data){
// 	    res.writeHead(200,{"Content-Type":"text/html;charset=UTF-8"});
// 	    res.end(data);
// 	});
//     }
// });
// server.listen(8080,function(){
//     console.log('running at 8080......');
// });
// 登录页面的路由文件



var mysql      = require('mysql');
var app = express();
app.use(bodyParser.urlencoded({ extended: false })) //固定写法
app.use(express.static(path.join(__dirname, '')))
// html文件的全局变量
//var indexRouter =  require('./login-register.html');

/**
 * 配置express使框架能够支持访问静态页面
 */
// // 1、告诉express框架模板文件所在的位置
// app.set('views', path.join(__dirname, 'views'));
// // 2、告诉express框架模板后缀是什么
// app.set('view engine', 'art');
// // 3、当渲染后缀为art模板时，所使用的模板引擎是什么
// app.engine('art', require('express-art-template'));
//global.webPath = path.join(__dirname,   "views") + path.sep; req.hostname,
var connection = mysql.createConnection({
    host     : 'localhost',
    user     : 'root',
    password : '123456',
    database : 'sale'
  });connection.connect();
  // 单图上传
app.post('/upload', upload.single('logo'), function(req, res, next){
    var file = req.file;

    console.log('文件类型：%s', file.mimetype);
    console.log('原始文件名：%s', file.originalname);
    console.log('文件大小：%s', file.size);
    console.log('文件保存路径：%s', file.path);
    res.send({ret_code: '0',originalname:file.path});
});
app.post('/user', (req, res) => {
    console.log(req.body);
    const username=req.body.username,password= req.body.password,email= req.body.email;
 //  const dbRes =db.addUser(req.body.username, req.body.password, req.body.email);
   var  addSql = 'INSERT INTO user(username,password,email) VALUES(?,?,?)';
  var  addSqlParams = [username, password,email];  var  querySqlParams = [username, password];
  var  queryql = 'SELECT 1 from user  where username=?';
connection.query(queryql,querySqlParams, function (error, results, fields) {
    if (error) throw error;
  //  console.log('The solution is: ', results[0]['1']);
    if (results.length==0){
               //增
  connection.query(addSql,addSqlParams,function (err, result) {
    if(err){
     console.log('[INSERT ERROR] - ',err.message);
     return;
    }        
    res.send('ok');return;
   console.log('--------------------------INSERT----------------------------');
   //console.log('INSERT ID:',result.insertId);        
   console.log('INSERT ID:',result);        
   console.log('-----------------------------------------------------------------\n\n');  
});
       
    }
    else{
      res.send('用户名或者邮箱被占用');return;
      //return '用户名或者邮箱被占用';
    }


  });
 
  // console.log(dbRes);
    
  })


  app.post('/userLogin', (req, res) => {

    const username=req.body.username,password= req.body.password,email= req.body.email;
 //  const dbRes =db.addUser(req.body.username, req.body.password, req.body.email);
 var  querySqlParams = [username, password];
  var  queryql = 'SELECT 1 from user  where username=? and password=?';
connection.query(queryql,querySqlParams, function (error, results, fields) {
    if (error) throw error;
    console.log('The solution is: ', results);
    if (results.length==0){
       
      res.send('用户名或密码错误');return;
  
      }
    if (results[0]['1']==1){
        res.send('ok');return;
        //return '用户名或者邮箱被占用';
    }
    else{
       
    res.send('用户名或密码错误');return;

    }


  });
 
  // console.log(dbRes);
    
  })
  app.post('/product', (req, res) => {
    console.log(req.body);
    const name=req.body.name,img= req.body.img,price= req.body.price;
 //  const dbRes =db.addUser(req.body.username, req.body.password, req.body.email);
   var  addSql = 'INSERT INTO product(name,img,price) VALUES(?,?,?)';
  var  addSqlParams = [name, img,price];  

         //增
  connection.query(addSql,addSqlParams,function (err, result) {
    if(err){
     console.log('[INSERT ERROR] - ',err.message);
     return;
    }        
   


  });
  res.send('ok');
  // console.log(dbRes);
    
  })
  app.get('/product', (req, res) => {
    console.log(req.body);
    const name=req.body.name,img= req.body.img,price= req.body.price;
 //  const dbRes =db.addUser(req.body.username, req.body.password, req.body.email);
   var  addSql = 'select * from product';
  var  addSqlParams = [name, img,price];  

         //增
  connection.query(addSql,function (err, result) {
    if(err){
     console.log('[INSERT ERROR] - ',err.message);
     return;
    }        
    res.json(result);


  });
  
  // console.log(dbRes);
    
  })
app.use(logger('dev'));

app.use(express.json());

app.use(express.urlencoded({ extended:   false }));

app.use(cookieParser());

app.use(express.static(path.join(__dirname,   'public')));

 

// 登录页面的路由访问路径

//app.use('/', indexRouter);

 

// catch 404 and forward to error   handler

app.use(function(req, res, next) {

    next(createError(404));

});

 

// error handler

// app.use(function(err, req, res, next) {

//     // set locals, only providing error in development

//     res.locals.message = err.message;

//     res.locals.error = req.app.get('env') === 'development' ? err : {};

 

//     // render the error page

//     res.status(err.status || 500);

//     res.render('error');

// });



module.exports = app;